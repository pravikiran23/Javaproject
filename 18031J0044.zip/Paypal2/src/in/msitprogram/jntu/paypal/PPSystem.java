package in.msitprogram.jntu.paypal;
import java.io.IOException;
import in.msitprogram.jntu.paypal.console.MainMenu;
/**
 * @author pg
 *
 */
public class PPSystem 
{

	public static void main(String[] args) throws IOException, ClassNotFoundException 
	{
		MainMenu.show();
	}

}
