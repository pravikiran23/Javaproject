package in.msitprogram.jntu.paypal.accounts;

import java.io.Serializable;
import java.util.ArrayList;

public class PPAccount implements Serializable
{
	/**
	 * 
	 */
	private Profile profile;
	private String email;
	private float accountBal;
	private boolean isActivated;
	private String activationCode;
	private ArrayList<Transaction> transactions;
	public PPAccount(Profile profile,String email) {
		// TODO Auto-generated constructor stub
		this.profile = profile;
		this.email = email;
		transactions = new ArrayList<Transaction>();
	}
	public String toString()
	{
		// implement this function to return a beautiful looking string
		// to display the summary of the account
		return "Profile:"+profile+"\n"+"Email:"+email+"\n"+"AccountBal:"+accountBal;
	}
    public Profile getProfile() {
		return profile;
	}
     public void setProfile(Profile profile) {
		this.profile = profile;
	}

	public float getAccountBal() {
		return accountBal;
	}

	public void setAccountBal(float accountBal) {
		this.accountBal = accountBal;
	}

	public boolean isActivated() {
		return isActivated;
	}

	public void setActivated(boolean isActivated) {
		this.isActivated = isActivated;
	}

	public String getActivationCode() {
		return activationCode;
	}

	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}

	public ArrayList<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(Transaction t) {
		this.transactions.add(t);
	}

	public void setEmail(String email) {
		this.email = email;
	}

	

	public void activate(String activationCode) 
	{
		
		// TODO Auto-generated method stub
		
	}
	
	public void suspend() 
	{
		// TODO Auto-generated method stub
	}


	public boolean withdraw(float withdrawAmount) {
		
		accountBal = accountBal-withdrawAmount;
		return false;
	}


	public boolean addFunds(float creditAmount) 
	{
		accountBal = accountBal+creditAmount;
		
		return false;
	}
	
	public boolean sendMoney(float creditAmount) 
	{
		
		return false;
	}
	
	public boolean requestMoney(float creditAmount) 
	{
		
		return false;
	}

	public String getEmail() {
		// TODO Auto-generated method stub
		return email;
	}
	
}
