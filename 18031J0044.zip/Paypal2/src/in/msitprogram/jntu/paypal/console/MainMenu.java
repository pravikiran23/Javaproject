/**
 * 
 */
package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.util.Scanner;

/**
 * @author pg
 *
 */
public class MainMenu {
	
	public static void show() throws IOException, ClassNotFoundException{
		//show the welcome message with the main menu options
		
		//take the menu option as input from the console
		
		//take email address as input from the console
		
		//based on the given menu option instantiate the respective screens
		
		System.out.println("---------------------------");
		System.out.println("---------------------------");
		System.out.println("---------------------------");
		System.out.println("---- **** PAYPAL **** -----");
		System.out.println("---------------------------");
		System.out.println("---------------------------");
		System.out.println("---------------------------");
		Scanner input = new Scanner(System.in);
		System.out.println("Please Choose Your Option from Below");
		System.out.println("\n1.Do you have Account Please choose this option for Sign In.\n2.Are you a New user please choose this option for Create Account.");
		int n = input.nextInt();
		switch (n) {
		case 1: System.out.println("Enter Email ID");
				String email = input.next();
			    PPAccountScreen PPAS = new PPAccountScreen(email);
			    PPAS.show();
			break;
		case 2: System.out.println("Enter Email Id:");
		        String email1 = input.next();
		        PPNewAccountScreen PPNAS = new PPNewAccountScreen(email1);
		        PPNAS.show();
		default:
			break;
		}
		
		
		
	}

}
