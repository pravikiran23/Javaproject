package in.msitprogram.jntu.paypal.console;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.persistance.DataStore;
import in.msitprogram.jntu.paypal.utils.PPToolkit;

import java.io.IOException;
import java.util.Scanner;

public class PPAccountActivationScreen {
	
	public static void show() throws IOException, ClassNotFoundException {
		
		String email = ""; //change to get console input
		System.out.println("1.Suspending.\n2.Activating");
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		PPAccount account = null;
		switch(n)
		{
		case 1: System.out.println("Enter Email");
		        email = input.next();
		        try
		        {
		        	account = DataStore.lookupAccount(email);
		        }
		        catch(Exception e)
		        {
		        	
		        }
		        finally
		        {
		        	if(account!=null)
		        	{
		        		if(account.isActivated())
		        		{
		        			account.setActivated(false);
		        			DataStore.writeAccount(account);
		        			System.out.println("Your account is suspended");
		        			MainMenu.show();
		        		}
		        		else
		        		{
		        			System.out.println("Your account is in inactive state");
		        			MainMenu.show();
		        		}
		        	}
		        	else
		        	{
		        		System.out.println("Your account doesnt exists");
		        		MainMenu.show();
		        	}
		        }
		        break;
		case 2: System.out.println("Enter Email");
		email = input.next();
		try
		{
			account = DataStore.lookupAccount(email);
		}
		catch(Exception e)
		{
			
		}
		finally
		{
			if(account!=null)
			{
				if(!account.isActivated())
				{
					String s = account.getActivationCode();
					System.out.println("Enter your activation code");
					String em = input.next();
					if(em.equals(s))
					{
						account.setActivated(true);
						System.out.println("Your account is activated");
						DataStore.writeAccount(account);
						MainMenu.show();
					}
				}
				else
				{
				System.out.println("your account is in inactive state");
				MainMenu.show();
				}
			}
			else
			{
				System.out.println("Your account doesnt exsist");
				MainMenu.show();
			}
		}
		break;
		}
		
		/*
		 * TODO
		 * fetch the account object using email address
		 * check if the account is suspended
		 * if suspended then activate it
		 * if activation code invalid, retry for 2 more attempts
		 * on successful activation show main menu
		 * on failure show the error message and continue to main menu
		 */				
		
          
		//check if account is active. if yes then ask for suspending it
		
		// if yes suspend it if not go back to main menu
		
		// accept activation code, check if valid, if not give 2 more attempts
		
		//proceed to main menu
		
	
	}

}