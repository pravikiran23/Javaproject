package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.accounts.PPRestrictedAccount;
import in.msitprogram.jntu.paypal.accounts.Transaction;
import in.msitprogram.jntu.paypal.persistance.DataStore;

public class PPAccountScreen implements Serializable{
	PPAccount account;
	Scanner scan;
	
	public PPAccountScreen(String email) throws ClassNotFoundException, IOException {
		scan = new Scanner(System.in);
		account = DataStore.lookupAccount(email);
	}

	public void show() throws IOException, ClassNotFoundException {
		
		//check if account is active
		
		//if active
		
			// print the account summary
		if(account.isActivated())
		{
			System.out.println(account);
			int n;
			do
			{
			System.out.println("1.Deposit.\n2.Withdraw.\n3.Request Money.\n4.Send Money.\n5.Transaction History\n6.Logout.");
			System.out.println("Enter any of the options");
			Scanner input = new Scanner(System.in);
			 n = input.nextInt();
			
			switch(n)
			{
			case 1: addFunds();
			        //DataStore.writeAccount(account);
			        //MainMenu.show();
			        break;
			case 2: withdrawFunds();
			       // DataStore.writeAccount(account);
			       // MainMenu.show();
			        break;
			case 3: requestMoney();
			        break;
			case 4: sendMoney();
			        break;
			
			case 5: ArrayList<Transaction> al=new ArrayList<Transaction>();
		       al=account.getTransactions();
		       for(Transaction t:al)
		       {
		    	   System.out.println(t);
		       }
		       break;
			case 6: MainMenu.show();
	                break;
				
			}
			}while(n!=6);
		}
		else
		{
			System.out.println("Activate your Account");
		}
			
			
			// print menu and accept menu options
			// for all the paypal account operations
			
			
		
	}

	private void withdrawFunds() throws IOException, ClassNotFoundException {
		// implement the withdraw funds user interface here
		
		//use the account object as needed for withdraw funds
		if(account instanceof PPRestrictedAccount)
		{
			Scanner input = new Scanner(System.in);
			System.out.println("Enter amount that you want to withdraw");
			float withdrawAmount = input.nextFloat();
			float bal1 = account.getAccountBal();
			if(withdrawAmount>5000)
			{
				System.out.println("Limit Crossed");
			}
			else
			{
				if(bal1>withdrawAmount)
				{
					account.setAccountBal(account.getAccountBal()-withdrawAmount);
				}
				else
				{
					System.out.println("Insufficient Funds");
					MainMenu.show();
				}
			}
			LocalTime tT = LocalTime.now();
			LocalDate tD = LocalDate.now();
			String tTime = String.valueOf(tT);
			String tDate = String.valueOf(tD);
			String narration = "debited";
		    String reference = account.getEmail();
		    String status = "withdraw";
			float debit = withdrawAmount;
			float credit = 0;
			ArrayList<Transaction> t = new ArrayList<Transaction>();
			Transaction t1 = new Transaction(tTime,tDate,account,narration,reference,status,debit,credit);
			account.setTransactions(t1);
			DataStore.writeAccount(account);
			System.out.println("Present balance is"+account.getAccountBal());
		    
		}
		else
			
		{
				
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter amount that you want to withdraw");
		float withdrawAmount=sc.nextFloat();
		float bal1=account.getAccountBal();
		if(bal1>withdrawAmount)
		{
		bal1=bal1-withdrawAmount;
		}
		else
		{
		System.out.println("Insufficient Funds");
		MainMenu.show();
		}
		
		LocalTime tT = LocalTime.now();
		LocalDate tD = LocalDate.now();
		String tTime = String.valueOf(tT);
		String tDate = String.valueOf(tD);
		String narration = "debited";
	    String reference = account.getEmail();
	    String status = "withdraw";
		float debit = withdrawAmount ;
		float credit = 0;
		ArrayList<Transaction> t = new ArrayList<Transaction>();
		Transaction t1 = new Transaction(tTime,tDate,account,narration,reference,status,debit,credit);
		account.setTransactions(t1);
	    account.setAccountBal(account.getAccountBal()-withdrawAmount);
		DataStore.writeAccount(account);
		System.out.println("Present balance is"+bal1);
		}
				
		
		
	}

	private void requestMoney() {
		// 	implement the request money user interface here
		
		//use the account object as needed for request money funds
	}

	private void sendMoney() {
		// implement the send money user interface here
		
		//use the account object as needed for send money funds
	}

	private void addFunds() throws IOException, ClassNotFoundException {
		// implement the add funds user interface here
		
		//use the account object as needed for add funds
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter amount that you want to add");
		float creditAmount=sc.nextFloat();
		float bal=account.getAccountBal();
		bal=bal+creditAmount;
		LocalTime tT = LocalTime.now();
		LocalDate tD = LocalDate.now();
		String tTime = String.valueOf(tT);
		String tDate = String.valueOf(tD);
		String narration = "credited";
	    String reference = account.getEmail();
	    String status = "add";
		float debit = 0;
		float credit = creditAmount;
		ArrayList<Transaction> t = new ArrayList<Transaction>();
		Transaction t1 = new Transaction(tTime,tDate,account,narration,reference,status,debit,credit);
		account.setTransactions(t1);
		account.setAccountBal(account.getAccountBal()+creditAmount);
		DataStore.writeAccount(account);
		System.out.println("Present balance is"+bal);

	}

}